# Payments by check

## About

This module allows you to accept payments by x days.

